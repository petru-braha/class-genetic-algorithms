#include <iostream>
#include "math/dependencies/value.hpp"
//#include "math/dependencies/value.hpp"
//#include "functions.hpp"

#define TEST_NUMBER 30
#define PRECISION 5

//void heuristic_execution(const function&, unsigned char);

int main()
{
    srand((unsigned int)time(0));

    // choose function // calculate N
    
    // choose dimension: 2 / 10
    // choose approach:  d / h
    
    // execution // calculate time
    
    // compare results with known 

    return 0;
}
