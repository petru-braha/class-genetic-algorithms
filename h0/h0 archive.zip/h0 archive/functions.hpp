#ifndef _0FUNCTIONS0_
#define _0FUNCTIONS0_

#include "math/functions/michalewicz.hpp"
#include "math/functions/rastrigin.hpp"
#include "math/functions/schwefel.hpp"
#include "math/functions/de_jong_1.hpp"

#endif
