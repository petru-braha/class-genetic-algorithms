#include "functions.hpp"

void deterministic_execution()
{
    
}
